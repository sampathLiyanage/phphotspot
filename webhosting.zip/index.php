<?php
if (isset($_GET['error_msg'])) {
    echo "{\"error\": \"".$_GET['error_msg']."\"}";
    die;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="bower_components/angular-material/angular-material.css">
    <style>
        .tabsdemoDynamicHeight md-content {
            background-color: transparent !important;
        }
        .tabsdemoDynamicHeight md-content md-tabs {
            background: #f6f6f6;
            border: 1px solid #e1e1e1;
        }
        .tabsdemoDynamicHeight md-content md-tabs md-tabs-wrapper {
            background: white;
        }
        .tabsdemoDynamicHeight md-content h1:first-child {
            margin-top: 0;
        }
        md-tabs > md-tabs-wrapper > md-tabs-canvas > md-pagination-wrapper > md-ink-bar {
            color: red;
            background: red;
        }
        md-tabs > md-tabs-wrapper > md-tabs-canvas > md-pagination-wrapper > md-tab-item:not([disabled]) {
            color: grey;
        }
        md-tabs > md-tabs-wrapper > md-tabs-canvas > md-pagination-wrapper > md-tab-item:not([disabled]).md-active {
            color: darkblue;
        }
        .logo {
            width: 50px;
        }
        .fixed-toolbar {
            position: fixed;
        }
        .tab-panel {
            padding-top:80px;
        }
        .left-panel {
            padding-top:120px;
        }
        md-card > md-card-content {
            padding: 8px;
        }
        md-card-content > p {
            font-size: 14px;
        }
        md-input-container {
            font-size: 14px;
            padding-bottom: 0px;
        }
        md-card .md-title {
            font-size: 16px;
            margin-bottom: 0px;
        }
        .md-mini span {
            color: gray;
        }
        .listdemoListControls md-divider {
            margin-top: 10px;
            margin-bottom: 10px; }
        .listdemoListControls md-list-item > p, .listdemoListControls md-list-item > .md-list-item-inner > p, .listdemoListControls md-list-item .md-list-item-inner > p, .listdemoListControls md-list-item .md-list-item-inner > .md-list-item-inner > p {
            -webkit-user-select: none;
            /* Chrome all / Safari all */
            -moz-user-select: none;
            /* Firefox all */
            -ms-user-select: none;
            /* IE 10+ */
            user-select: none;
            /* Likely future */ }
        md-list-item p {
            padding-top: 5px;
            padding-bottom: 5px;
        }
        h1 span.main-title {
            margin-left: 10px;
        }
        .md-subheader .md-subheader-inner {
            padding-top:0px;
        }
    </style>
</head>
<body ng-app="webHosting">
<md-toolbar class="fixed-toolbar">
    <div class="md-toolbar-tools">
        <img ng-src="logo.png" class="md-card-image" alt="Washed Out">
        <h1>
            <span class="main-title">Free Web Hosting</span>
        </h1>
        <span flex></span>
        <md-button class="md-raised md-warn">Sign Up</md-button>
    </div>
</md-toolbar>
<div layout="row">
    <div flex="10">
    </div>
    <div flex="60">
        <div ng-cloak>
            <md-content class="tab-panel">
                <md-tabs md-dynamic-height md-border-bottom>
                    <md-tab label="Free Hosting">
                        <md-content class="md-padding">
                            <h1 class="md-display-2">Hosting Plans</h1>
                            <md-card>
                             <img ng-src="plan.png" class="md-card-image" alt="Washed Out">
                                    <md-card-content>
                            <p>
                                Before purchasing our 'vip' or 'super vip' plans you have to SIGN UP for a free account. Then you can upgrate your account.
                            </p>
                            </md-card-content>
                            </md-card></md-content>
                    </md-tab>
                    <md-tab label="Sign Up">
                        <md-content class="md-padding">
                            <h1 class="md-display-2">Sign Up</h1>
                            <div id="api-client-signup">
                                <form ng-submit="submit()" ng-controller="signupController" id="reg" name="reg" method="post">
                                    <div class="api_input" id="api_email">
                                        <label for="email">Email address</label><br/>
                                        <input type="text" name="email" id="email" ng-model="singupFormData.email" value=""></div>
                                    <div class="api_input" id="api_first_name">
                                        <label for="first_name">Name</label><br/>
                                        <input type="text" name="first_name" ng-model="singupFormData.firstName" id="first_name" value=""></div>
                                    <div class="api_input" id="api_country">
                                        <label for="country">Country</label><br/>
                                        <select name="country" id="country" ng-model="singupFormData.country">
                                            <option value="0">Choose a country</option>
                                            <option value="AF">Afghanistan</option>
                                            <option value="AX">Åland Islands</option>
                                            <option value="AL">Albania</option>
                                            <option value="DZ">Algeria</option>
                                            <option value="AS">American Samoa</option>
                                            <option value="AD">Andorra</option>
                                            <option value="AO">Angola</option>
                                            <option value="AI">Anguilla</option>
                                            <option value="AQ">Antarctica</option>
                                            <option value="AG">Antigua and Barbuda</option>
                                            <option value="AR">Argentina</option>
                                            <option value="AM">Armenia</option>
                                            <option value="AW">Aruba</option>
                                            <option value="AU">Australia</option>
                                            <option value="AT">Austria</option>
                                            <option value="AZ">Azerbaijan</option>
                                            <option value="BS">Bahamas</option>
                                            <option value="BH">Bahrain</option>
                                            <option value="BD">Bangladesh</option>
                                            <option value="BB">Barbados</option>
                                            <option value="BY">Belarus</option>
                                            <option value="BE">Belgium</option>
                                            <option value="BZ">Belize</option>
                                            <option value="BJ">Benin</option>
                                            <option value="BM">Bermuda</option>
                                            <option value="BT">Bhutan</option>
                                            <option value="BO">Bolivia</option>
                                            <option value="BA">Bosnia and Herzegovina</option>
                                            <option value="BW">Botswana</option>
                                            <option value="BV">Bouvet Island</option>
                                            <option value="BR">Brazil</option>
                                            <option value="BQ">British Antarctic Territory</option>
                                            <option value="IO">British Indian Ocean Territory</option>
                                            <option value="VG">British Virgin Islands</option>
                                            <option value="BN">Brunei</option>
                                            <option value="BG">Bulgaria</option>
                                            <option value="BF">Burkina Faso</option>
                                            <option value="BI">Burundi</option>
                                            <option value="KH">Cambodia</option>
                                            <option value="CM">Cameroon</option>
                                            <option value="CA">Canada</option>
                                            <option value="CT">Canton and Enderbury Islands</option>
                                            <option value="CV">Cape Verde</option>
                                            <option value="KY">Cayman Islands</option>
                                            <option value="CF">Central African Republic</option>
                                            <option value="TD">Chad</option>
                                            <option value="CL">Chile</option>
                                            <option value="CN">China</option>
                                            <option value="CX">Christmas Island</option>
                                            <option value="CC">Cocos [Keeling] Islands</option>
                                            <option value="CO">Colombia</option>
                                            <option value="KM">Comoros</option>
                                            <option value="CG">Congo - Brazzaville</option>
                                            <option value="CD">Congo - Kinshasa</option>
                                            <option value="CK">Cook Islands</option>
                                            <option value="CR">Costa Rica</option>
                                            <option value="CI">Côte d’Ivoire</option>
                                            <option value="HR">Croatia</option>
                                            <option value="CU">Cuba</option>
                                            <option value="CY">Cyprus</option>
                                            <option value="CZ">Czech Republic</option>
                                            <option value="DK">Denmark</option>
                                            <option value="DJ">Djibouti</option>
                                            <option value="DM">Dominica</option>
                                            <option value="DO">Dominican Republic</option>
                                            <option value="NQ">Dronning Maud Land</option>
                                            <option value="DD">East Germany</option>
                                            <option value="EC">Ecuador</option>
                                            <option value="EG">Egypt</option>
                                            <option value="SV">El Salvador</option>
                                            <option value="GQ">Equatorial Guinea</option>
                                            <option value="ER">Eritrea</option>
                                            <option value="EE">Estonia</option>
                                            <option value="ET">Ethiopia</option>
                                            <option value="FK">Falkland Islands</option>
                                            <option value="FO">Faroe Islands</option>
                                            <option value="FJ">Fiji</option>
                                            <option value="FI">Finland</option>
                                            <option value="FR">France</option>
                                            <option value="GF">French Guiana</option>
                                            <option value="PF">French Polynesia</option>
                                            <option value="FQ">French Southern and Antarctic Territories</option>
                                            <option value="TF">French Southern Territories</option>
                                            <option value="GA">Gabon</option>
                                            <option value="GM">Gambia</option>
                                            <option value="GE">Georgia</option>
                                            <option value="DE">Germany</option>
                                            <option value="GH">Ghana</option>
                                            <option value="GI">Gibraltar</option>
                                            <option value="GR">Greece</option>
                                            <option value="GL">Greenland</option>
                                            <option value="GD">Grenada</option>
                                            <option value="GP">Guadeloupe</option>
                                            <option value="GU">Guam</option>
                                            <option value="GT">Guatemala</option>
                                            <option value="GG">Guernsey</option>
                                            <option value="GN">Guinea</option>
                                            <option value="GW">Guinea-Bissau</option>
                                            <option value="GY">Guyana</option>
                                            <option value="HT">Haiti</option>
                                            <option value="HM">Heard Island and McDonald Islands</option>
                                            <option value="HN">Honduras</option>
                                            <option value="HK">Hong Kong SAR China</option>
                                            <option value="HU">Hungary</option>
                                            <option value="IS">Iceland</option>
                                            <option value="IN">India</option>
                                            <option value="ID">Indonesia</option>
                                            <option value="IR">Iran</option>
                                            <option value="IQ">Iraq</option>
                                            <option value="IE">Ireland</option>
                                            <option value="IM">Isle of Man</option>
                                            <option value="IL">Israel</option>
                                            <option value="IT">Italy</option>
                                            <option value="JM">Jamaica</option>
                                            <option value="JP">Japan</option>
                                            <option value="JE">Jersey</option>
                                            <option value="JT">Johnston Island</option>
                                            <option value="JO">Jordan</option>
                                            <option value="KZ">Kazakhstan</option>
                                            <option value="KE">Kenya</option>
                                            <option value="KI">Kiribati</option>
                                            <option value="KW">Kuwait</option>
                                            <option value="KG">Kyrgyzstan</option>
                                            <option value="LA">Laos</option>
                                            <option value="LV">Latvia</option>
                                            <option value="LB">Lebanon</option>
                                            <option value="LS">Lesotho</option>
                                            <option value="LR">Liberia</option>
                                            <option value="LY">Libya</option>
                                            <option value="LI">Liechtenstein</option>
                                            <option value="LT">Lithuania</option>
                                            <option value="LU">Luxembourg</option>
                                            <option value="MO">Macau SAR China</option>
                                            <option value="MK">Macedonia</option>
                                            <option value="MG">Madagascar</option>
                                            <option value="MW">Malawi</option>
                                            <option value="MY">Malaysia</option>
                                            <option value="MV">Maldives</option>
                                            <option value="ML">Mali</option>
                                            <option value="MT">Malta</option>
                                            <option value="MH">Marshall Islands</option>
                                            <option value="MQ">Martinique</option>
                                            <option value="MR">Mauritania</option>
                                            <option value="MU">Mauritius</option>
                                            <option value="YT">Mayotte</option>
                                            <option value="FX">Metropolitan France</option>
                                            <option value="MX">Mexico</option>
                                            <option value="FM">Micronesia</option>
                                            <option value="MI">Midway Islands</option>
                                            <option value="MD">Moldova</option>
                                            <option value="MC">Monaco</option>
                                            <option value="MN">Mongolia</option>
                                            <option value="ME">Montenegro</option>
                                            <option value="MS">Montserrat</option>
                                            <option value="MA">Morocco</option>
                                            <option value="MZ">Mozambique</option>
                                            <option value="MM">Myanmar [Burma]</option>
                                            <option value="NA">Namibia</option>
                                            <option value="NR">Nauru</option>
                                            <option value="NP">Nepal</option>
                                            <option value="NL">Netherlands</option>
                                            <option value="AN">Netherlands Antilles</option>
                                            <option value="NT">Neutral Zone</option>
                                            <option value="NC">New Caledonia</option>
                                            <option value="NZ">New Zealand</option>
                                            <option value="NI">Nicaragua</option>
                                            <option value="NE">Niger</option>
                                            <option value="NG">Nigeria</option>
                                            <option value="NU">Niue</option>
                                            <option value="NF">Norfolk Island</option>
                                            <option value="MP">Northern Mariana Islands</option>
                                            <option value="KP">North Korea</option>
                                            <option value="VD">North Vietnam</option>
                                            <option value="NO">Norway</option>
                                            <option value="OM">Oman</option>
                                            <option value="PC">Pacific Islands Trust Territory</option>
                                            <option value="PK">Pakistan</option>
                                            <option value="PW">Palau</option>
                                            <option value="PS">Palestinian Territories</option>
                                            <option value="PA">Panama</option>
                                            <option value="PZ">Panama Canal Zone</option>
                                            <option value="PG">Papua New Guinea</option>
                                            <option value="PY">Paraguay</option>
                                            <option value="YD">People's Democratic Republic of Yemen</option>
                                            <option value="PE">Peru</option>
                                            <option value="PH">Philippines</option>
                                            <option value="PN">Pitcairn Islands</option>
                                            <option value="PL">Poland</option>
                                            <option value="PT">Portugal</option>
                                            <option value="PR">Puerto Rico</option>
                                            <option value="QA">Qatar</option>
                                            <option value="RE">Réunion</option>
                                            <option value="RO">Romania</option>
                                            <option value="RU">Russia</option>
                                            <option value="RW">Rwanda</option>
                                            <option value="BL">Saint Barthélemy</option>
                                            <option value="SH">Saint Helena</option>
                                            <option value="KN">Saint Kitts and Nevis</option>
                                            <option value="LC">Saint Lucia</option>
                                            <option value="MF">Saint Martin</option>
                                            <option value="PM">Saint Pierre and Miquelon</option>
                                            <option value="VC">Saint Vincent and the Grenadines</option>
                                            <option value="WS">Samoa</option>
                                            <option value="SM">San Marino</option>
                                            <option value="ST">São Tomé and Príncipe</option>
                                            <option value="SA">Saudi Arabia</option>
                                            <option value="SN">Senegal</option>
                                            <option value="RS">Serbia</option>
                                            <option value="CS">Serbia and Montenegro</option>
                                            <option value="SC">Seychelles</option>
                                            <option value="SL">Sierra Leone</option>
                                            <option value="SG">Singapore</option>
                                            <option value="SK">Slovakia</option>
                                            <option value="SI">Slovenia</option>
                                            <option value="SB">Solomon Islands</option>
                                            <option value="SO">Somalia</option>
                                            <option value="ZA">South Africa</option>
                                            <option value="GS">South Georgia and the South Sandwich Islands</option>
                                            <option value="KR">South Korea</option>
                                            <option value="ES">Spain</option>
                                            <option value="LK">Sri Lanka</option>
                                            <option value="SD">Sudan</option>
                                            <option value="SR">Suriname</option>
                                            <option value="SJ">Svalbard and Jan Mayen</option>
                                            <option value="SZ">Swaziland</option>
                                            <option value="SE">Sweden</option>
                                            <option value="CH">Switzerland</option>
                                            <option value="SY">Syria</option>
                                            <option value="TW">Taiwan</option>
                                            <option value="TJ">Tajikistan</option>
                                            <option value="TZ">Tanzania</option>
                                            <option value="TH">Thailand</option>
                                            <option value="TL">Timor-Leste</option>
                                            <option value="TG">Togo</option>
                                            <option value="TK">Tokelau</option>
                                            <option value="TO">Tonga</option>
                                            <option value="TT">Trinidad and Tobago</option>
                                            <option value="TN">Tunisia</option>
                                            <option value="TR">Turkey</option>
                                            <option value="TM">Turkmenistan</option>
                                            <option value="TC">Turks and Caicos Islands</option>
                                            <option value="TV">Tuvalu</option>
                                            <option value="UG">Uganda</option>
                                            <option value="UA">Ukraine</option>
                                            <option value="SU">Union of Soviet Socialist Republics</option>
                                            <option value="AE">United Arab Emirates</option>
                                            <option value="GB">United Kingdom</option>
                                            <option value="US">United States</option>
                                            <option value="ZZ">Unknown or Invalid Region</option>
                                            <option value="UY">Uruguay</option>
                                            <option value="UM">U.S. Minor Outlying Islands</option>
                                            <option value="PU">U.S. Miscellaneous Pacific Islands</option>
                                            <option value="VI">U.S. Virgin Islands</option>
                                            <option value="UZ">Uzbekistan</option>
                                            <option value="VU">Vanuatu</option>
                                            <option value="VA">Vatican City</option>
                                            <option value="VE">Venezuela</option>
                                            <option value="VN">Vietnam</option>
                                            <option value="WK">Wake Island</option>
                                            <option value="WF">Wallis and Futuna</option>
                                            <option value="EH">Western Sahara</option>
                                            <option value="YE">Yemen</option>
                                            <option value="ZM">Zambia</option>
                                            <option value="ZW">Zimbabwe</option>
                                        </select></div>
                                    <div class="api_input" id="api_password">
                                        <label for="password">Password</label><br/>
                                        <input type="password" name="password" id="password" ng-model="singupFormData.password" value=""></div>
                                    <div class="api_input" id="api_password_confirm">
                                        <label for="password_confirm">Confirm Password</label><br/>
                                        <input type="password" name="password_confirm" id="password_confirm" ng-model="singupFormData.password_confirm" value=""></div>
                                    <div class="api_input" id="api_captcha">
                                        <label for="captcha">Type the characters you see below</label><br/><img alt="captcha" ng-src="{{captchaUrl}}"/><br/>
                                        <input type="text" name="captcha" id="captcha" ng-model="singupFormData.captcha" value="" captcha_src="{{captchaUrl}}"></div>

                                    <input type="submit" name="submit" id="submit" value="Save">
                                </form>
                            </div>

                             </md-content>
                    </md-tab>
                    <md-tab label="Contact Us">
                        <md-content class="md-padding">
                            <h1 class="md-display-2">Contact Us</h1>
                            <p>Integer turpis erat, porttitor vitae mi faucibus, laoreet interdum tellus. Curabitur posuere molestie dictum. Morbi eget congue risus, quis rhoncus quam. Suspendisse vitae hendrerit erat, at posuere mi. Cras eu fermentum nunc. Sed id ante eu orci commodo volutpat non ac est. Praesent ligula diam, congue eu enim scelerisque, finibus commodo lectus.</p>
                        </md-content>
                    </md-tab>
                    <md-tab label="Terms">
                        <md-content class="md-padding">
                            <h1 class="md-display-2">Terms</h1>
                            <md-list ng-cloak>
                                <md-subheader class="md-no-sticky">You agree to not use the Service to:</md-subheader>
                                <md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any Content that is unlawful, harmful, threatening, abusive, harassing, tortious, defamatory, vulgar, obscene, libelous, invasive of another's privacy, hateful, or racially, ethnically or otherwise objectionable.</p>
                                </md-list-item>
                                <md-divider></md-divider>
                                <md-list-item ">
                                    <p>Impersonate any person or entity, including, but not limited to, a Byet official, forum leader, guide or host, or falsely state or otherwise misrepresent your affiliation with a person or entity.</p>
                                </md-list-item>
                                <md-divider></md-divider>
                                <md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any Content that you do not have a right to make available under any law or under contractual or fiduciary relationships (such as inside information, proprietary and confidential information learned or disclosed as part of employment relationships or under nondisclosure agreements).</p>
                                </md-list-item>
                                <md-divider></md-divider>
                                <md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any Content that infringes any patent, trademark, trade secret, copyright or other proprietary rights ("Rights") of any party; This includes linking to or redirecting to any content or copyright files hosted on a 3rd party resource / servers.</p>
                                </md-list-item>
                                <md-divider></md-divider><md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any unsolicited or unauthorized advertising, promotional materials, "junk mail," "spam," "chain letters," "pyramid schemes," or any other form of solicitation, except in those areas (such as shopping) that are designated for such purpose (please read our complete Spam Policy).</p>
                                </md-list-item>
                                <md-divider></md-divider><md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any material that contains software viruses or any other computer code, files or programs designed to interrupt, destroy or limit the functionality of any computer software or hardware or telecommunications equipment.</p>
                                </md-list-item>
                                <md-divider></md-divider><md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any material that is of broadcast / streaming types.</p>
                                </md-list-item>
                                <md-divider></md-divider>
                                <md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any material that is of,
                                        keylogging / proxy service / irc / shell(s) if any type / file hosting / file sharing types.</p>
                                </md-list-item>
                                <md-divider></md-divider>
                                <md-list-item ">
                                    <p>Upload, post, email, transmit or otherwise make available any material on free hosting accounts that is of pornographic nature. This excludes premium paid hosting accounts (cPanel/WHM hosting accounts).</p>
                                </md-list-item>
                                <md-divider></md-divider><md-list-item ">
                                    <p>Interfere with or disrupt the Service or servers or networks connected to the Service, or disobey any requirements, procedures, policies or regulations of networks connected to the Service.</p>
                                </md-list-item>
                                <md-divider></md-divider>
                                <md-list-item ">
                                    <p>Intentionally or unintentionally violate any applicable local, state, national or international law, including, but not limited to, regulations promulgated by the U.S. Securities and Exchange Commission, any rules of any national or other securities exchange, including, without limitation, the New York Stock Exchange, the American Stock Exchange or the NASDAQ, and any regulations having the force of law.</p>
                                </md-list-item>
                                <md-divider></md-divider><md-list-item ">
                                    <p>Provide material support or resources (or to conceal or disguise the nature, location, source, or ownership of material support or resources) to any organization(s) designated by the United States government as a foreign terrorist organization pursuant to section 219 of the Immigration and Nationality Act.</p>
                                </md-list-item>
                            </md-list>
                        </md-content>
                    </md-tab>
                </md-tabs>
            </md-content>
        </div>
    </div>
    <div flex="20">
            <div flex>
                <div  ng-controller="leftPanelController"  ng-cloak>
                    <md-content class="md-padding left-panel">
                        <md-card>
                            <img ng-src="php-mysql.jpg" class="md-card-image" alt="Washed Out">
                            <md-card-content>
                                <p>
                                    Professional, PHP, MySQL hosting, powered by clustered technology. We use only the highest quality hardware and up-to-date software.
                                </p>
                            </md-card-content>
                        </md-card>
                        <br>
                        <md-card>
                            <img ng-src="no-add.jpg" class="md-card-image" alt="Washed Out">
                            <md-card-content>
                                <p>
                                    We don't put any kind of advertisement or any other content on your webpages.
                                </p>
                            </md-card-content>
                        </md-card>
                        <br/>
                        <md-card>
                            <img ng-src="one-click-install.jpg" class="md-card-image" alt="Washed Out">
                            <md-card-content>
                                <p>
                                    Install more than 60 apps including joomla, wordpress and drupal with just a single click.
                                </p>
                            </md-card-content>
                        </md-card>
                        <br/>
                        <md-card>
                            <img ng-src="99.jpg" class="md-card-image" alt="Washed Out">
                            <md-card-content>
                                <p>
                                    Our hosting comes with 99% uptime guarantee. Servers are powerful and stable. Servers utilize 1 Gbps internet connections.
                                </p>
                            </md-card-content>
                        </md-card>
                    </md-content>
                </div>
            </div>
    </div>
    <div flex="10">
    </div>
</div>



<script src="bower_components/angular/angular.js"></script>
<script src="bower_components/angular-aria/angular-aria.js"></script>
<script src="bower_components/angular-animate/angular-animate.js"></script>
<script src="bower_components/angular-material/angular-material.js"></script>
<script>
    angular
        .module('webHosting', ['ngMaterial'])
        .controller('leftPanelController', function($scope) {
            $scope.imagePath = "http://cdn.thumbr.io/7a5920d28234569b213660f322165bab/KhPZbWboUluRxv8PG87L/www.freepik.com/blog/wp-content/uploads/2015/11/Thanksgiving-day.jpg/800/thumb.jpg";
        })
        .controller('signupController', function($scope,$http) {
            var oringinalCaptchaUrl = "http://api.freelk.asia/captcha?transparent=1";
            $scope.singupFormData = {};
            $scope.captchaUrl = oringinalCaptchaUrl;
            $scope.submit = function() {
                console.log(this.singupFormData);
                var req = {
                    method: 'POST',
                    url: "http://api.freelk.asia/v-2/client-register",
                    headers: {
                        enctype: "application/x-www-form-urlencoded"
                    },
                    data: this.singupFormData
                }

                $http(req).then(function successCallback(response) {
                    console.log("success");
                    if ('error' in response.data) {
                        $scope.captchaUrl = oringinalCaptchaUrl+'&cb='+(new Date()).toString();
                    }
                    console.log(response);
                }, function errorCallback(response) {
                    $scope.captchaUrl = oringinalCaptchaUrl+'&cb='+(new Date()).toString();
                    console.log('error')
                    console.log(response);
                });
            }
        });

</script>

</body>
</html>